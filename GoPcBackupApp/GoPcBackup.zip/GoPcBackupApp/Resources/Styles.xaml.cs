using System.Windows;
using System.Windows.Input;


namespace GoPcBackup
{
    partial class Styles : ResourceDictionary
    { 
        public Styles()
        {
            InitializeComponent();
        }

        // Event handlers go here.
    }
}
