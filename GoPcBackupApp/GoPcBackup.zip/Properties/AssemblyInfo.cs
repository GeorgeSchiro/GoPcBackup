using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("GoPcBackup")]
[assembly: AssemblyDescription("GoPC Backup and Archiver")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("George Schiro")]
[assembly: AssemblyProduct("GoPcBackup")]
[assembly: AssemblyCopyright("Copyright © George Schiro 2013-2121")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("5.3")]
[assembly: AssemblyFileVersion("5.3")]
[assembly: NeutralResourcesLanguageAttribute("en-US")]
