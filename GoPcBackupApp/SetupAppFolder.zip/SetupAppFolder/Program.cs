using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using tvToolbox;
using vbAccelerator.Components.Shell;

namespace SetupAppFolder
{
    static class Program
    {
        [DllImport("shell32.dll")]
        public static extern Int32 SHParseDisplayName( [MarshalAs(UnmanagedType.LPWStr)]
                String pszName, IntPtr pbc, out IntPtr ppidl, UInt32 sfgaoIn,  out UInt32 psfgaoOut);
        [DllImport("Shell32.dll")]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            tvProfile loProfile = new tvProfile(args
                    , tvProfileDefaultFileActions.NoDefaultFile
                    , tvProfileFileCreateActions.NoFileCreate);

            string lsProjectFolderOldFullPath = loProfile.sValue("-ProjectFolderOldFullPath", "");

            if ( "" == lsProjectFolderOldFullPath )
            {
                // No "-ProjectFolderOldFullPath" switch means the
                // user just started this setup for the first time.

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new UI());
            }
            else
            {
                // Given "-ProjectFolderOldFullPath" switch means this setup
                // just restarted itself from the new installation folder.

                bool    lbNoErrorRunExe = true;
                string  lsExeName = null;
                string  lsExeNameExt = null;
                string  lsExePath = null;

                try
                {
                    lsExeName = Path.GetFileName(lsProjectFolderOldFullPath);
                    lsExeNameExt = lsExeName + ".exe";
                    lsExePath = Path.GetDirectoryName(Application.ExecutablePath);

                    string  lsDesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                    string  lsShortcutFile = lsExeName + ".lnk";
                    string  lsShortcutPathFile = Path.Combine(lsDesktopPath, lsShortcutFile);

                    try
                    {
                        ShellLink   loShellLink = new ShellLink();
                                    loShellLink.Target = Path.Combine(lsExePath, lsExeNameExt);
                                    loShellLink.WorkingDirectory = lsExePath;
                                    loShellLink.Description = lsExeName;
                                    loShellLink.DisplayMode = ShellLink.LinkDisplayMode.edmNormal;
                                    loShellLink.Save(lsShortcutPathFile);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error Creating Desktop Shortcut"
                                , MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    if ( loProfile.bValue("-CopyShortcutToStartup", false) )
                    {
                        try
                        {
                            File.Copy(lsShortcutPathFile, Path.Combine(
                                    Environment.GetFolderPath(Environment.SpecialFolder.Startup), lsShortcutFile), true);
                        }
                        catch (IOException ex)
                        {
                            lbNoErrorRunExe = false;

                            MessageBox.Show(ex.Message, "Error Copying Shortcut to Startup"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    if ( !loProfile.bValue("-AlreadyMoved", false) )
                    {
                        // Get out of the current directory before it gets deleted.
                        Directory.SetCurrentDirectory(lsDesktopPath);

                        try
                        {
                            Application.DoEvents();
                            System.Threading.Thread.Sleep(200);

                            Directory.Delete(lsProjectFolderOldFullPath, true);
                            Program.RefreshDesktop();
                        }
                        catch (IOException)
                        {
                            // Try again.
                            try
                            {
                                Application.DoEvents();
                                System.Threading.Thread.Sleep(200);

                                Directory.Delete(lsProjectFolderOldFullPath, true);
                                Program.RefreshDesktop();
                            }
                            catch (IOException ex)
                            {
                                lbNoErrorRunExe = false;

                                MessageBox.Show(ex.Message, "Error Removing Desktop Program Folder"
                                        , MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Moving to Installation Folder"
                            , MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if ( lbNoErrorRunExe )
                    {
                        string lsErrors = sRunFinishSetupScript(lsExePath);

                        if ( null != lsErrors )
                        {
                            MessageBox.Show(lsErrors, lsExeName);
                        }
                        else
                        {
                            Process loProcess = new Process();
                                    loProcess.StartInfo.FileName = Path.Combine(lsExePath, lsExeNameExt);
                                    loProcess.StartInfo.WorkingDirectory = lsExePath;
                                    loProcess.Start();
                        }
                    }
                }
            }
        }

        private static void RefreshDesktop()
        {
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
        }

        private static string sRunFinishSetupScript(string asExePath)
        {
            string lsScriptPathFile = Path.Combine(asExePath, "PostAppFolderSetup.ps1");

            if ( !File.Exists(lsScriptPathFile) )
                return null;

            string  lsErrors = null;
            int     liPowerScriptOutputRetries = 1;

            for (int i=0; i < liPowerScriptOutputRetries; i++)
            {
                Process loProcess = new Process();
                        loProcess.ErrorDataReceived += new DataReceivedEventHandler(PowerScriptProcessErrorHandler);
                        loProcess.StartInfo.FileName = "PowerShell.exe";
                        loProcess.StartInfo.Arguments = String.Format("-NoProfile -ExecutionPolicy unrestricted -File \"{0}\" {1} {2}", lsScriptPathFile, "-ExePath", asExePath);
                        loProcess.StartInfo.WorkingDirectory = Environment.CurrentDirectory;
                        loProcess.StartInfo.UseShellExecute = false;
                        loProcess.StartInfo.RedirectStandardError = true;
                        loProcess.StartInfo.RedirectStandardInput = true;
                        loProcess.StartInfo.RedirectStandardOutput = true;
                        loProcess.StartInfo.CreateNoWindow = true;

                System.Windows.Forms.Application.DoEvents();

                try
                {
                    loProcess.Start();
                }
                catch (Exception ex)
                {
                    lsErrors += (null == lsErrors ? "" : Environment.NewLine) + ex.Message;
                }

                loProcess.BeginErrorReadLine();
                loProcess.BeginOutputReadLine();

                DateTime ltdProcessTimeout = DateTime.Now.AddSeconds(30);

                // Wait for the process to finish.
                while ( !loProcess.HasExited && DateTime.Now < ltdProcessTimeout )
                {
                    System.Windows.Forms.Application.DoEvents();

                    Thread.Sleep(200);
                }

                if ( !loProcess.HasExited )
                    lsErrors += (null == lsErrors ? "" : Environment.NewLine) + "*** sub-process timed-out ***";

                int liExitCode = -1;
                    try { liExitCode = loProcess.ExitCode; } catch {}

                if ( null != msPowerScriptError || liExitCode != 0 || !loProcess.HasExited )
                {
                    if ( null != msPowerScriptError )
                        lsErrors += (null == lsErrors ? "" : Environment.NewLine) + msPowerScriptError;
                    else
                        lsErrors += (null == lsErrors ? "" : Environment.NewLine) + "The sub-process experienced a critical failure.";
                }

                loProcess.CancelErrorRead();
                loProcess.CancelOutputRead();

                if ( null == lsErrors )
                {
                    break;
                }
                else
                {
                    System.Windows.Forms.Application.DoEvents();
                    Thread.Sleep(1000);
                }
            }

            return lsErrors;
        }
        private static string msPowerScriptError = null;

        public static void PowerScriptProcessErrorHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            if ( null != outLine.Data && 0 != outLine.Data.Length )
                msPowerScriptError += outLine.Data;
        }
    }
}
