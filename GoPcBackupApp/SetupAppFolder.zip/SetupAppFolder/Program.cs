using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using tvToolbox;
using vbAccelerator.Components.Shell;

namespace SetupAppFolder
{
    static class Program
    {
        [DllImport("shell32.dll")]
        public static extern Int32 SHParseDisplayName( [MarshalAs(UnmanagedType.LPWStr)]
                String pszName, IntPtr pbc, out IntPtr ppidl, UInt32 sfgaoIn,  out UInt32 psfgaoOut);
        [DllImport("Shell32.dll")]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            tvProfile loProfile = new tvProfile(args
                    , tvProfileDefaultFileActions.NoDefaultFile
                    , tvProfileFileCreateActions.NoFileCreate);

            string lsProjectFolderOldFullPath = loProfile.sValue("-ProjectFolderOldFullPath", "");

            if ( "" == lsProjectFolderOldFullPath )
            {
                // No "-ProjectFolderOldFullPath" switch means the
                // user just started this setup for the first time.

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new UI());
            }
            else
            {
                // Given "-ProjectFolderOldFullPath" switch means this setup
                // just restarted itself from a new folder in "program files".

                try
                {
                    string  lsExeName = Path.GetFileName(lsProjectFolderOldFullPath);
                    string  lsExeNameExt = lsExeName + ".exe";
                    string  lsExePath = Path.GetDirectoryName(Application.ExecutablePath);
                    string  lsDesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                    string  lsShortcutFile = lsExeName + ".lnk";
                    string  lsShortcutPathFile = Path.Combine(lsDesktopPath, lsShortcutFile);

                    try
                    {
                        ShellLink   loShellLink = new ShellLink();
                                    loShellLink.Target = Path.Combine(lsExePath, lsExeNameExt);
                                    loShellLink.WorkingDirectory = lsExePath;
                                    loShellLink.Description = lsExeName;
                                    loShellLink.DisplayMode = ShellLink.LinkDisplayMode.edmNormal;
                                    loShellLink.Save(lsShortcutPathFile);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error Creating Desktop Shortcut"
                                , MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    if ( loProfile.bValue("-CopyShortcutToStartup", false) )
                    {
                        try
                        {
                            File.Copy(lsShortcutPathFile, Path.Combine(
                                    Environment.GetFolderPath(Environment.SpecialFolder.Startup), lsShortcutFile), true);
                        }
                        catch (IOException ex)
                        {
                            MessageBox.Show(ex.Message, "Error Copying Shortcut to Startup"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    // Get out of the current directory before it gets deleted.
                    Directory.SetCurrentDirectory(lsDesktopPath);

                    try
                    {
                        Application.DoEvents();
                        System.Threading.Thread.Sleep(200);

                        Directory.Delete(lsProjectFolderOldFullPath, true);
                        Program.RefreshDesktop();
                    }
                    catch (IOException)
                    {
                        // Try again.
                        try
                        {
                            Application.DoEvents();
                            System.Threading.Thread.Sleep(200);

                            Directory.Delete(lsProjectFolderOldFullPath, true);
                            Program.RefreshDesktop();
                        }
                        catch (IOException ex)
                        {
                            MessageBox.Show(ex.Message, "Error Removing Desktop Program Folder"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Moving to Program Files"
                            , MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        static void RefreshDesktop()
        {
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);
        }
    }
}
