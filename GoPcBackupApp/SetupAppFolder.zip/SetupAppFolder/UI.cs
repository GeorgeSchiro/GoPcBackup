using Microsoft.VisualBasic.Devices;
using System;
using System.Diagnostics;
using System.IO;
using System.Security.AccessControl;
using System.Windows.Forms;


namespace SetupAppFolder
{
    public partial class UI : Form
    {
        string msExeName    = null;
        string msAppPath    = null;
        string msExeNewPath = null;

        public UI()
        {
            InitializeComponent();

            msExeName = Path.GetFileName(Environment.CurrentDirectory);

            string[]    lsAppPathList = {
                                  Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
                                , Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
                                };

                        // Find the application folder (if it already exists).
                        // If not found, settle on the last item on the list.
                        foreach (string lsPath in lsAppPathList)
                        {
                            msAppPath = lsPath;
                            msExeNewPath = Path.Combine(msAppPath, msExeName);
                            if ( Directory.Exists(msExeNewPath) )
                                break;
                        }

            lblPrompt.Text = 
                    "Are you sure you want to move:{Newline}{Newline}\"{ProjectFolder}\"{Newline}{Newline} to \"{AppsFolder}\" ?"
                    .Replace("{ProjectFolder}", Environment.CurrentDirectory)
                    .Replace("{Newline}", Environment.NewLine)
                    .Replace("{AppsFolder}", msAppPath)
                    ;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if ( this.MoveFolder() )
                this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    
        private bool MoveFolder()
        {
            bool    lbMoveFolder = false;

            // Count running instances.
            Process[] loProcessesArray = Process.GetProcessesByName(msExeName);

            if ( 0 != loProcessesArray.Length )
            {
                MessageBox.Show(String.Format("\"{0}\" is still running. Please close it and try again.", msExeName + ".exe")
                        , msExeName);
            }
            else
            {
                // Now close the parent folder window (to allow for a desktop refresh later).
                foreach (Process loProcess in Process.GetProcessesByName("explorer"))
                {
                    try
                    {
                        loProcess.Kill();
                    }
                    catch {}
                }

                try
                {
                    // If the application folder already exists elsewhere, cleanup
                    // runtime folders in the current folder (ie. on the desktop).
                    if ( Directory.Exists(msExeNewPath) )
                    {
                        string[]    lsFolderCleanupList = { "FileLists", "Logs" };
                                    foreach (string lsFolder in lsFolderCleanupList)
                                    {
                                        string lsPath = Path.Combine(Environment.CurrentDirectory, lsFolder);
                                        if ( Directory.Exists(lsPath) )
                                            Directory.Delete(lsPath, true);
                                    }
                    }

                    // Copy the application from its current folder (eg. on the desktop) to the installation folder.
                    new Computer().FileSystem.CopyDirectory(Environment.CurrentDirectory, msExeNewPath, true);

                    // Set permissions to the new application installation folder.
                    DirectoryInfo       loDirectoryInfo = new DirectoryInfo(msExeNewPath);
                    DirectorySecurity   loDirectorySecurity = loDirectoryInfo.GetAccessControl();
                                        loDirectorySecurity.AddAccessRule(new FileSystemAccessRule("BUILTIN\\Users"
                                                ,   FileSystemRights.AppendData
                                                  | FileSystemRights.ChangePermissions
                                                  | FileSystemRights.CreateDirectories
                                                  | FileSystemRights.CreateFiles
                                                  | FileSystemRights.Delete
                                                  | FileSystemRights.DeleteSubdirectoriesAndFiles
                                                  | FileSystemRights.ExecuteFile
                                                  | FileSystemRights.FullControl
                                                  | FileSystemRights.ListDirectory
                                                  | FileSystemRights.Modify
                                                  | FileSystemRights.Read
                                                  | FileSystemRights.ReadAndExecute
                                                  | FileSystemRights.ReadAttributes
                                                  | FileSystemRights.ReadData
                                                  | FileSystemRights.ReadExtendedAttributes
                                                  | FileSystemRights.ReadPermissions
                                                  | FileSystemRights.Synchronize
                                                  | FileSystemRights.TakeOwnership
                                                  | FileSystemRights.Traverse
                                                  | FileSystemRights.Write
                                                  | FileSystemRights.WriteAttributes
                                                  | FileSystemRights.WriteData
                                                  | FileSystemRights.WriteExtendedAttributes
                                                , InheritanceFlags.ObjectInherit | InheritanceFlags.ContainerInherit
                                                , PropagationFlags.InheritOnly
                                                , AccessControlType.Allow
                                                ));

                                        loDirectoryInfo.SetAccessControl(loDirectorySecurity);

                    // Continue this setup process in the new application installation folder.
                    Process.Start(Path.Combine(msExeNewPath, Process.GetCurrentProcess().ProcessName + ".exe")
                            , " -ProjectFolderOldFullPath=\"" + Environment.CurrentDirectory + "\""
                            + " -CopyShortcutToStartup=" + chkCopyShortcutToStartup.Checked
                            );

                    // Get out of the current directory before it gets deleted (ie. step down to the desktop before folder deletion).
                    Directory.SetCurrentDirectory(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));

                    lbMoveFolder = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Attempting to Copy Program Folder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return lbMoveFolder;
        }
    }
}
