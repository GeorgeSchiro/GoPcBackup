using Microsoft.VisualBasic.Devices;
using System;
using System.Diagnostics;
using System.IO;
using System.Security.AccessControl;
using System.Windows.Forms;


namespace SetupAppFolder
{
    public partial class UI : Form
    {
        string msAppPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

        public UI()
        {
            InitializeComponent();

            lblPrompt.Text = 
                    "Are you sure you want to move:{Newline}{Newline}\"{ProjectFolder}\"{Newline}{Newline} to \"{AppsFolder}\" ?"
                    .Replace("{ProjectFolder}", Environment.CurrentDirectory)
                    .Replace("{Newline}", Environment.NewLine)
                    .Replace("{AppsFolder}", msAppPath)
                    ;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.MoveFolder();
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    
        private void MoveFolder()
        {
            string lsExeName = Path.GetFileName(Environment.CurrentDirectory);
            string lsExeProfile = lsExeName + ".exe.txt";
            string lsExeNewPath = Path.Combine(msAppPath, lsExeName);
            string lsExePreviousProfilePathFile = Path.Combine(lsExeNewPath, lsExeProfile);

            // Verify that the application to be moved is not still running.
            try
	        {
                FileStream  loFileStream = File.Open(lsExeProfile, FileMode.Open);
                            loFileStream.Close();
	        }
	        catch
	        {
                MessageBox.Show(string.Format("\"{0}.exe\" is still running. Please close it and try again.", lsExeName)
                        , string.Format("{0} Running", lsExeName));
                return;
	        }

            // Now close the parent folder window (to allow for a desktop refresh later).
            foreach (Process loProcess in Process.GetProcessesByName("explorer"))
            {
                try
                {
                    loProcess.Kill();
                }
                catch {}
            }

            try
            {
                // If a profile file already exists in the application folder within "Program Files",
                // delete the profile file in the current folder (ie. on the desktop).
                if ( File.Exists(lsExePreviousProfilePathFile) )
                    File.Delete(lsExeProfile);

                // Copy the application from its current folder (eg. on the desktop) to the "program files" folder.
                new Computer().FileSystem.CopyDirectory(Environment.CurrentDirectory, lsExeNewPath, true);

                // Set permissions to the new application folder in "program files".
                DirectoryInfo       loDirectoryInfo = new DirectoryInfo(lsExeNewPath);
                DirectorySecurity   loDirectorySecurity = loDirectoryInfo.GetAccessControl();
                                    loDirectorySecurity.AddAccessRule(new FileSystemAccessRule("BUILTIN\\Users"
                                            ,   FileSystemRights.AppendData
                                              | FileSystemRights.ChangePermissions
                                              | FileSystemRights.CreateDirectories
                                              | FileSystemRights.CreateFiles
                                              | FileSystemRights.Delete
                                              | FileSystemRights.DeleteSubdirectoriesAndFiles
                                              | FileSystemRights.ExecuteFile
                                              | FileSystemRights.FullControl
                                              | FileSystemRights.ListDirectory
                                              | FileSystemRights.Modify
                                              | FileSystemRights.Read
                                              | FileSystemRights.ReadAndExecute
                                              | FileSystemRights.ReadAttributes
                                              | FileSystemRights.ReadData
                                              | FileSystemRights.ReadExtendedAttributes
                                              | FileSystemRights.ReadPermissions
                                              | FileSystemRights.Synchronize
                                              | FileSystemRights.TakeOwnership
                                              | FileSystemRights.Traverse
                                              | FileSystemRights.Write
                                              | FileSystemRights.WriteAttributes
                                              | FileSystemRights.WriteData
                                              | FileSystemRights.WriteExtendedAttributes
                                            , InheritanceFlags.ObjectInherit | InheritanceFlags.ContainerInherit
                                            , PropagationFlags.InheritOnly
                                            , AccessControlType.Allow
                                            ));

                                    loDirectoryInfo.SetAccessControl(loDirectorySecurity);

                // Continue this setup process in the new application folder in "program files".
                Process.Start(Path.Combine(lsExeNewPath, Process.GetCurrentProcess().ProcessName + ".exe")
                        , " -ProjectFolderOldFullPath=\"" + Environment.CurrentDirectory + "\""
                        + " -CopyShortcutToStartup=" + chkCopyShortcutToStartup.Checked
                        );

                // Get out of the current directory before it gets deleted (ie. step down to the desktop before folder deletion).
                Directory.SetCurrentDirectory(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Attempting to Copy Program Folder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
    }
}
