using Microsoft.VisualBasic.Devices;
using System;
using System.Diagnostics;
using System.IO;
using System.Security.AccessControl;
using System.Windows.Forms;


namespace SetupAppFolder
{
    public partial class UI : Form
    {
        bool   mbAlreadyMoved   = false;
        string msExeName        = null;
        string msExeExt         = ".exe";
        string msAppPath        = null;
        string msExeNewPath     = null;

        public UI()
        {
            InitializeComponent();

            msExeName = Path.GetFileName(Environment.CurrentDirectory);

            string[]    lsAppPathList = {
                                  Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
                                , Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
                                };

                        // Find the application folder (if it already exists).
                        // If not found, settle on the last item on the list.
                        foreach (string lsPath in lsAppPathList)
                        {
                            msAppPath = lsPath;
                            msExeNewPath = Path.Combine(msAppPath, msExeName);
                            if ( Directory.Exists(msExeNewPath) )
                                break;
                        }

            mbAlreadyMoved = msAppPath == Path.GetDirectoryName(Environment.CurrentDirectory);

            if ( !mbAlreadyMoved )
                lblPrompt.Text = 
                        "Are you sure you want to move:{Newline}{Newline}\"{ProjectFolder}\"{Newline}{Newline} to \"{AppsFolder}\" ?"
                        .Replace("{ProjectFolder}", Environment.CurrentDirectory)
                        .Replace("{Newline}", Environment.NewLine)
                        .Replace("{AppsFolder}", msAppPath)
                        ;
            else
                lblPrompt.Text = 
                        "The application is already located in \"{AppsFolder}\".{Newline}{Newline} Do you want to finalize the setup for \"{ExeNameExt}\" ?"
                        .Replace("{Newline}", Environment.NewLine)
                        .Replace("{AppsFolder}", msAppPath)
                        .Replace("{ExeNameExt}", msExeName + msExeExt)
                        ;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if ( this.bMoveFolder() )
                this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    
        private bool bMoveFolder()
        {
            bool    lbMoveFolder = false;
            string  lsErrors = null;

            // Count running instances of the main EXE (we want this one on top).
            Process[] loProcessesArray = Process.GetProcessesByName(msExeName);

            if ( 0 != loProcessesArray.Length )
                lsErrors += (null == lsErrors ? "" : Environment.NewLine + Environment.NewLine) + String.Format("\"{0}\" is still running. Please close it and try again.", msExeName + msExeExt);

            string lsThisExeToLower = Path.GetFileNameWithoutExtension(Process.GetCurrentProcess().MainModule.FileName).ToLower();
            string lsMainExeToLower = msExeName.ToLower();

            if ( !mbAlreadyMoved )
                foreach (string lsExePathFile in Directory.GetFiles(Environment.CurrentDirectory, "*" + msExeExt))
                {
                    string  lsExeName = Path.GetFileNameWithoutExtension(lsExePathFile);
                    string  lsExeNameToLower = lsExeName.ToLower();
                            if ( lsExeNameToLower == lsThisExeToLower || lsExeNameToLower == lsMainExeToLower )
                                continue;

                    // Count running instances of this EXE.
                    loProcessesArray = Process.GetProcessesByName(lsExeName);

                    if ( 0 != loProcessesArray.Length )
                        lsErrors += (null == lsErrors ? "" : Environment.NewLine + Environment.NewLine) + String.Format("\"{0}\" is still running. Please close it and try again.", lsExeName + msExeExt);
                }

            if ( null != lsErrors )
            {
                MessageBox.Show(lsErrors, msExeName);
            }
            else
            {
                // Now close the parent folder window (to allow for a desktop refresh later).
                foreach (Process loProcess in Process.GetProcessesByName("explorer"))
                {
                    try
                    {
                        loProcess.Kill();
                    }
                    catch {}
                }

                if ( mbAlreadyMoved )
                {
                    // Continue this setup process in the application installation folder as if just moved.
                    Process.Start(Path.Combine(msExeNewPath, Process.GetCurrentProcess().ProcessName + msExeExt)
                            , " -ProjectFolderOldFullPath=\"" + Environment.CurrentDirectory + "\""
                            + " -CopyShortcutToStartup=" + chkCopyShortcutToStartup.Checked
                            + " -AlreadyMoved"
                            );

                    lbMoveFolder = true;
                }
                else
                {
                    try
                    {
                        // If the application folder already exists elsewhere, cleanup
                        // runtime folders in the current folder (ie. on the desktop).
                        if ( Directory.Exists(msExeNewPath) )
                        {
                            string[]    lsFolderCleanupList = { "FileLists", "Logs" };
                                        foreach (string lsFolder in lsFolderCleanupList)
                                        {
                                            string lsPath = Path.Combine(Environment.CurrentDirectory, lsFolder);
                                            if ( Directory.Exists(lsPath) )
                                                Directory.Delete(lsPath, true);
                                        }
                        }

                        // Copy the application from its current folder (eg. on the desktop) to the installation folder.
                        new Computer().FileSystem.CopyDirectory(Environment.CurrentDirectory, msExeNewPath, true);

                        // Set permissions to the new application installation folder.
                        DirectoryInfo       loDirectoryInfo = new DirectoryInfo(msExeNewPath);
                        DirectorySecurity   loDirectorySecurity = loDirectoryInfo.GetAccessControl();
                                            loDirectorySecurity.AddAccessRule(new FileSystemAccessRule("BUILTIN\\Users"
                                                    ,   FileSystemRights.AppendData
                                                      | FileSystemRights.ChangePermissions
                                                      | FileSystemRights.CreateDirectories
                                                      | FileSystemRights.CreateFiles
                                                      | FileSystemRights.Delete
                                                      | FileSystemRights.DeleteSubdirectoriesAndFiles
                                                      | FileSystemRights.ExecuteFile
                                                      | FileSystemRights.FullControl
                                                      | FileSystemRights.ListDirectory
                                                      | FileSystemRights.Modify
                                                      | FileSystemRights.Read
                                                      | FileSystemRights.ReadAndExecute
                                                      | FileSystemRights.ReadAttributes
                                                      | FileSystemRights.ReadData
                                                      | FileSystemRights.ReadExtendedAttributes
                                                      | FileSystemRights.ReadPermissions
                                                      | FileSystemRights.Synchronize
                                                      | FileSystemRights.TakeOwnership
                                                      | FileSystemRights.Traverse
                                                      | FileSystemRights.Write
                                                      | FileSystemRights.WriteAttributes
                                                      | FileSystemRights.WriteData
                                                      | FileSystemRights.WriteExtendedAttributes
                                                    , InheritanceFlags.ObjectInherit | InheritanceFlags.ContainerInherit
                                                    , PropagationFlags.InheritOnly
                                                    , AccessControlType.Allow
                                                    ));

                                            loDirectoryInfo.SetAccessControl(loDirectorySecurity);

                        // Continue this setup process in the new application installation folder.
                        Process.Start(Path.Combine(msExeNewPath, Process.GetCurrentProcess().ProcessName + msExeExt)
                                , " -ProjectFolderOldFullPath=\"" + Environment.CurrentDirectory + "\""
                                + " -CopyShortcutToStartup=" + chkCopyShortcutToStartup.Checked
                                );

                        // Get out of the current directory before it gets deleted (ie. step down to the desktop before folder deletion).
                        Directory.SetCurrentDirectory(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));

                        lbMoveFolder = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error Attempting to Copy Program Folder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            return lbMoveFolder;
        }
    }
}
